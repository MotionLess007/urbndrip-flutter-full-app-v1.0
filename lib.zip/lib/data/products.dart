import '../models/product.dart';

final List<Product> products = [
  Product(
    name: "Twill Overshirt",
    price: 56.0,
    image: "assets/p1.jpeg",
    rating: 4.5,
    category: "Overshirt",
    description: "Premium twill overshirt with relaxed fit.",
  ),

  Product(
    name: "Slim Fit T-shirt",
    price: 42.0,
    image: "assets/p2.jpeg",
    rating: 4.2,
    category: "T-shirt",
    description: "Soft cotton slim fit t-shirt for everyday wear.",
  ),

  Product(
    name: "Hoodie",
    price: 75.0,
    image: "assets/p3.jpeg",
    rating: 4.8,
    category: "Hoodie",
    description: "Comfortable oversized hoodie with premium fabric.",
  ),

  Product(
    name: "Cargo Pants",
    price: 68.0,
    image: "assets/p4.jpeg",
    rating: 4.3,
    category: "Pants",
    description: "Streetwear cargo pants with utility pockets.",
  ),
];