import 'package:flutter/material.dart';
import 'checkout_screen.dart';
import '../data/cart_data.dart';
import '../models/cart_item.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {

  @override
  Widget build(BuildContext context) {

    // 💰 TOTAL PRICE
    double total = 0;

    for (var item in cartItems) {
      total += item.product.price * item.quantity;
    }

    return Scaffold(
      backgroundColor: const Color(0xFFEFEFEF),

      body: SafeArea(
        child: Column(
          children: [

            // 🔝 HEADER
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),

              child: Row(
                mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,

                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back),
                  ),

                  const Text(
                    "CART",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),

                  const SizedBox(width: 40),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // 🛍️ EMPTY CART
            if (cartItems.isEmpty)
              const Expanded(
                child: Center(
                  child: Text(
                    "Your cart is empty 🛒",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              )

            // 🛍️ DYNAMIC ITEMS
            else
              Expanded(
                child: ListView(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16),

                  children: List.generate(
                    cartItems.length,
                    (index) => Padding(
                      padding:
                          const EdgeInsets.only(bottom: 12),

                      child: CartProductCard(
                        item: cartItems[index],

                        // 🔄 REFRESH UI
                        onUpdate: () {
                          setState(() {});
                        },
                      ),
                    ),
                  ),
                ),
              ),

            // 💰 TOTAL + BUTTON
            if (cartItems.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(16),

                decoration: const BoxDecoration(
                  color: Colors.white,

                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(20),
                  ),
                ),

                child: Column(
                  children: [

                    // 💰 TOTAL
                    Row(
                      mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,

                      children: [
                        const Text("Total"),

                        Text(
                          "\$${total.toStringAsFixed(2)}",

                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.orange,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 12),

                    // 🔘 CHECKOUT BUTTON
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                const CheckoutScreen(),
                          ),
                        );
                      },

                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,

                        minimumSize:
                            const Size(double.infinity, 50),

                        shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(30),
                        ),
                      ),

                      child: const Text("Checkout"),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// 🛍️ CART PRODUCT CARD
class CartProductCard extends StatelessWidget {
  final CartItem item;
  final VoidCallback onUpdate;

  const CartProductCard({
    required this.item,
    required this.onUpdate,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),

      child: Row(
        children: [

          // 🖼️ PRODUCT IMAGE
          Container(
            width: 70,
            height: 70,

            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),

              image: DecorationImage(
                image:
                    AssetImage(item.product.image),
                fit: BoxFit.cover,
              ),
            ),
          ),

          const SizedBox(width: 12),

          // 📦 PRODUCT DETAILS
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [

                // 🧾 NAME
                Text(
                  item.product.name,

                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 4),

                // ⭐ RATING
                Text(
                  "⭐ ${item.product.rating}",

                  style: const TextStyle(
                    color: Colors.grey,
                  ),
                ),

                const SizedBox(height: 4),

                // 💰 PRICE
                Text(
                  "\$${item.product.price}",

                  style: const TextStyle(
                    color: Colors.orange,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),

          // 🔢 ACTIONS
          Column(
            children: [

              // 🗑️ DELETE
              GestureDetector(
                onTap: () {

                  // 🗑️ REMOVE ITEM
                  cartItems.remove(item);

                  // 🔄 REFRESH UI
                  onUpdate();
                },

                child: const Icon(
                  Icons.delete_outline,
                  color: Colors.red,
                ),
              ),

              const SizedBox(height: 8),

              // ➕
              GestureDetector(
                onTap: () {
                  item.quantity++;
                  onUpdate();
                },

                child: const Icon(
                  Icons.add_circle_outline,
                ),
              ),

              const SizedBox(height: 4),

              // 🔢 QUANTITY
              Text(item.quantity.toString()),

              const SizedBox(height: 4),

              // ➖
              GestureDetector(
                onTap: () {

                  if (item.quantity > 1) {
                    item.quantity--;
                    onUpdate();
                  }
                },

                child: const Icon(
                  Icons.remove_circle_outline,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}