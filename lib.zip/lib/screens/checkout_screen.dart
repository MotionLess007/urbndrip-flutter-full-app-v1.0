import 'dart:ui';
import 'package:flutter/material.dart';
import 'order_success_screen.dart';
import '../data/cart_data.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  String selectedPayment = "Credit Card";

  @override
  Widget build(BuildContext context) {

    // 💰 CALCULATE TOTAL
    double subtotal = 0;

    for (var item in cartItems) {
      subtotal += item.product.price * item.quantity;
    }

    double delivery = 10;
    double total = subtotal + delivery;

    return Scaffold(
      backgroundColor: const Color(0xFFEFEFEF),

      body: SafeArea(
        child: Column(
          children: [

            const SizedBox(height: 10),

            // 🔝 HEADER
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16),

              child: Row(
                children: [

                  // 🔙 BACK BUTTON
                  Container(
                    padding: const EdgeInsets.all(10),

                    decoration: BoxDecoration(
                      shape: BoxShape.circle,

                      border: Border.all(
                        color: Colors.grey.shade300,
                      ),
                    ),

                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: const Icon(Icons.arrow_back),
                    ),
                  ),

                  const Spacer(),

                  // 🏷️ LOGO
                  const Text(
                    "URBNDRIP",

                    style: TextStyle(
                      fontFamily: "Inter",
                      fontWeight: FontWeight.bold,
                      fontStyle: FontStyle.italic,
                      fontSize: 18,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // 🧾 TITLE
            const Padding(
              padding:
                  EdgeInsets.symmetric(horizontal: 16),

              child: Align(
                alignment: Alignment.centerLeft,

                child: Text(
                  "Checkout",

                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // 🧊 MAIN CARD
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),

                child: ClipRRect(
                  borderRadius: BorderRadius.circular(30),

                  child: Stack(
                    children: [

                      // 🖼️ BACKGROUND
                      Positioned.fill(
                        child: Image.asset(
                          "assets/checkoutbg.jpeg",
                          fit: BoxFit.cover,
                        ),
                      ),

                      // 🌑 OVERLAY
                      Positioned.fill(
                        child: Container(
                          color:
                              Colors.black.withOpacity(0.2),
                        ),
                      ),

                      // 📜 CONTENT
                      SingleChildScrollView(
                        padding:
                            const EdgeInsets.all(16),

                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,

                          children: [

                            // 👤 CUSTOMER INFORMATION
                          sectionTitle("Customer Information"),

                          const SizedBox(height: 10),

                          glassContainer(
                            child: const Column(
                              children: [

                                // 👤 FULL NAME
                                TextField(
                                  style: TextStyle(color: Colors.white),

                                  decoration: InputDecoration(
                                    hintText: "Full Name",
                                    hintStyle:
                                        TextStyle(color: Colors.white70),
                                    border: InputBorder.none,
                                  ),
                                ),

                                Divider(color: Colors.white24),

                                // 📧 EMAIL
                                TextField(
                                  style: TextStyle(color: Colors.white),

                                  keyboardType:
                                      TextInputType.emailAddress,

                                  decoration: InputDecoration(
                                    hintText: "Email Address",
                                    hintStyle:
                                        TextStyle(color: Colors.white70),
                                    border: InputBorder.none,
                                  ),
                                ),

                                Divider(color: Colors.white24),

                                // 📱 CONTACT NUMBER
                                TextField(
                                  style: TextStyle(color: Colors.white),

                                  keyboardType: TextInputType.phone,

                                  decoration: InputDecoration(
                                    hintText: "Contact Number",
                                    hintStyle:
                                        TextStyle(color: Colors.white70),
                                    border: InputBorder.none,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 20),

                          // 📍 DELIVERY ADDRESS
                          sectionTitle("Delivery Address"),

                          const SizedBox(height: 10),

                          glassContainer(
                            child: const TextField(
                              style: TextStyle(
                                color: Colors.white,
                              ),

                              maxLines: 2,

                              decoration: InputDecoration(
                                hintText: "Enter your address",

                                hintStyle: TextStyle(
                                  color: Colors.white70,
                                ),

                                border: InputBorder.none,
                              ),
                            ),
                          ),

                          const SizedBox(height: 20),

                            // 🛍️ ORDER SUMMARY
                            sectionTitle("Order Summary"),

                            const SizedBox(height: 10),

                            // 🛒 DYNAMIC CART ITEMS
                            Column(
                              children: List.generate(
                                cartItems.length,
                                (index) {

                                  final item =
                                      cartItems[index];

                                  return glassContainer(
                                    child: CheckoutItem(
                                      name:
                                          item.product.name,

                                      detail:
                                          "Qty: ${item.quantity}",

                                      price:
                                          "\$${(item.product.price * item.quantity).toStringAsFixed(2)}",

                                      image:
                                          item.product.image,
                                    ),
                                  );
                                },
                              ),
                            ),

                            const SizedBox(height: 20),

                            // 💰 PRICE SUMMARY
                            glassContainer(
                              child: Column(
                                children: [

                                  PriceRow(
                                    "Subtotal",
                                    "\$${subtotal.toStringAsFixed(2)}",
                                  ),

                                  PriceRow(
                                    "Delivery",
                                    "\$${delivery.toStringAsFixed(2)}",
                                  ),

                                  const Divider(
                                    color:
                                        Colors.white30,
                                  ),

                                  PriceRow(
                                    "Total",
                                    "\$${total.toStringAsFixed(2)}",
                                    isBold: true,
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 20),

                            // 💳 PAYMENT METHOD
                        sectionTitle("Payment Method"),

                        const SizedBox(height: 10),

                        glassContainer(
                          child: DropdownButtonFormField<String>(
                            value: selectedPayment,

                            dropdownColor: Colors.grey[900],

                            icon: const Icon(
                              Icons.keyboard_arrow_down,
                              color: Colors.white,
                            ),

                            style: const TextStyle(color: Colors.white),

                            decoration: const InputDecoration(
                              border: InputBorder.none,
                            ),

                            items: const [
                              DropdownMenuItem(
                                value: "Credit Card",
                                child: Text("Credit Card"),
                              ),

                              DropdownMenuItem(
                                value: "Cash on Delivery",
                                child: Text("Cash on Delivery"),
                              ),
                            ],

                            onChanged: (value) {
                              setState(() {
                                selectedPayment = value!;
                              });
                            },
                          ),
                        ),

                        const SizedBox(height: 20),

                        // 💳 CARD DETAILS
                        if (selectedPayment == "Credit Card")
                          glassContainer(
                            child: Column(
                              children: [

                                // 💳 CARD HOLDER NAME
                                const TextField(
                                  style: TextStyle(color: Colors.white),

                                  decoration: InputDecoration(
                                    hintText: "Card Holder Name",
                                    hintStyle:
                                        TextStyle(color: Colors.white70),
                                    border: InputBorder.none,
                                  ),
                                ),

                                const Divider(color: Colors.white24),

                                // 💳 CARD NUMBER
                                const TextField(
                                  style: TextStyle(color: Colors.white),

                                  keyboardType: TextInputType.number,

                                  decoration: InputDecoration(
                                    hintText: "Card Number",
                                    hintStyle:
                                        TextStyle(color: Colors.white70),
                                    border: InputBorder.none,
                                  ),
                                ),

                                const Divider(color: Colors.white24),

                                // 📅 EXPIRY + CVV
                                Row(
                                  children: [

                                    // 📅 EXPIRY DATE
                                    const Expanded(
                                      child: TextField(
                                        style:
                                            TextStyle(color: Colors.white),

                                        keyboardType:
                                            TextInputType.datetime,

                                        decoration: InputDecoration(
                                          hintText: "MM/YY",

                                          hintStyle: TextStyle(
                                            color: Colors.white70,
                                          ),

                                          border: InputBorder.none,
                                        ),
                                      ),
                                    ),

                                    Container(
                                      width: 1,
                                      height: 30,
                                      color: Colors.white24,
                                    ),

                                    // 🔒 CVV
                                    const Expanded(
                                      child: TextField(
                                        style:
                                            TextStyle(color: Colors.white),

                                        keyboardType:
                                            TextInputType.number,

                                        obscureText: true,

                                        decoration: InputDecoration(
                                          hintText: "CVV",

                                          hintStyle: TextStyle(
                                            color: Colors.white70,
                                          ),

                                          border: InputBorder.none,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),

                        const SizedBox(height: 100),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // 🔘 PLACE ORDER BUTTON
            Container(
              padding: const EdgeInsets.all(16),

              decoration: const BoxDecoration(
                color: Colors.white,

                borderRadius:
                    BorderRadius.vertical(
                  top: Radius.circular(20),
                ),
              ),

              child: ElevatedButton(
                onPressed: () {

                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          const OrderSuccessScreen(),
                    ),
                  );
                },

                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,

                  minimumSize:
                      const Size(double.infinity, 50),

                  shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(30),
                  ),
                ),

                child: const Text("Place Order"),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 🏷️ SECTION TITLE
  Widget sectionTitle(String text) {
    return Text(
      text,

      style: const TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 16,
        color: Colors.white,
      ),
    );
  }
}

// 🧊 GLASS CONTAINER
Widget glassContainer({required Widget child}) {
  return Container(
    margin: const EdgeInsets.only(bottom: 10),

    child: ClipRRect(
      borderRadius: BorderRadius.circular(16),

      child: BackdropFilter(
        filter:
            ImageFilter.blur(sigmaX: 10, sigmaY: 10),

        child: Container(
          padding: const EdgeInsets.all(16),

          decoration: BoxDecoration(
            color:
                Colors.white.withOpacity(0.15),

            borderRadius:
                BorderRadius.circular(16),

            border: Border.all(
              color:
                  Colors.white.withOpacity(0.2),
            ),
          ),

          child: child,
        ),
      ),
    ),
  );
}

// 🛍️ CHECKOUT ITEM
class CheckoutItem extends StatelessWidget {
  final String name;
  final String detail;
  final String price;
  final String image;

  const CheckoutItem({
    required this.name,
    required this.detail,
    required this.price,
    required this.image,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [

        // 🖼️ PRODUCT IMAGE
        Container(
          width: 60,
          height: 60,

          decoration: BoxDecoration(
            borderRadius:
                BorderRadius.circular(12),

            image: DecorationImage(
              image: AssetImage(image),
              fit: BoxFit.cover,
            ),
          ),
        ),

        const SizedBox(width: 10),

        // 📦 DETAILS
        Expanded(
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [
              Text(
                name,
                style: const TextStyle(
                  color: Colors.white,
                ),
              ),

              Text(
                detail,
                style: const TextStyle(
                  color: Colors.white70,
                ),
              ),
            ],
          ),
        ),

        // 💰 PRICE
        Text(
          price,

          style: const TextStyle(
            color: Colors.orange,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}

// 💰 PRICE ROW
class PriceRow extends StatelessWidget {
  final String title;
  final String price;
  final bool isBold;

  const PriceRow(
    this.title,
    this.price, {
    this.isBold = false,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(vertical: 4),

      child: Row(
        mainAxisAlignment:
            MainAxisAlignment.spaceBetween,

        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
            ),
          ),

          Text(
            price,

            style: TextStyle(
              color: Colors.white,

              fontWeight: isBold
                  ? FontWeight.bold
                  : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}