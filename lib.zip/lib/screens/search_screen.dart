import 'package:flutter/material.dart';
import 'detail_screen.dart';
import 'cart_screen.dart';
import '../data/products.dart';
import '../models/product.dart';
import '../data/favorite_data.dart';


class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {

  // 🔍 SEARCHED PRODUCTS
  List<Product> filteredProducts = products;

  // 🔍 SEARCH FUNCTION
  void searchProduct(String query) {

    final results = products.where((product) {

      final nameLower =
          product.name.toLowerCase();

      final searchLower =
          query.toLowerCase();

      return nameLower.contains(searchLower);

    }).toList();

    setState(() {
      filteredProducts = results;
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: const Color(0xFFEFEFEF),

      body: SafeArea(
        child: Column(
          children: [

            // 🔝 HEADER
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16),

              child: Row(
                mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,

                children: [

                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.menu),
                  ),

                  const Text(
                    "URBNDRIP",

                    style: TextStyle(
                      fontFamily: "Inter",
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontStyle: FontStyle.italic,
                    ),
                  ),

                  // 🛒 CART BUTTON
                  Stack(
                    children: [

                      IconButton(
                        onPressed: () {
                          Navigator.push(
                            context,

                            MaterialPageRoute(
                              builder: (context) =>
                                  const CartScreen(),
                            ),
                          );
                        },

                        icon: const Icon(
                          Icons.shopping_cart,
                        ),
                      ),

                      const Positioned(
                        right: 8,
                        top: 8,

                        child: CircleAvatar(
                          radius: 6,
                          backgroundColor: Colors.red,

                          child: Text(
                            "2",

                            style: TextStyle(
                              fontSize: 8,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // 🔍 SEARCH BAR
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16),

              child: Row(
                children: [

                  Expanded(
                    child: Container(
                      padding:
                          const EdgeInsets.symmetric(
                        horizontal: 12,
                      ),

                      decoration: BoxDecoration(
                        color: Colors.white,

                        borderRadius:
                            BorderRadius.circular(30),
                      ),

                      child: Row(
                        children: [

                          const Icon(Icons.search),

                          const SizedBox(width: 8),

                          Expanded(
                            child: TextField(

                              // 🔍 LIVE SEARCH
                              onChanged: searchProduct,

                              decoration:
                                  const InputDecoration(
                                hintText: "Search",

                                border:
                                    InputBorder.none,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(width: 10),

                  circleButton(Icons.tune),

                  const SizedBox(width: 8),

                  circleButton(Icons.swap_vert),
                ],
              ),
            ),

            const SizedBox(height: 15),

            // 🏷️ CATEGORY
            SizedBox(
              height: 50,

              child: ListView(
                scrollDirection: Axis.horizontal,

                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 16,
                ),

                children: const [
                  CategoryChip(
                    "Trend",
                    isActive: true,
                  ),

                  CategoryChip("T-shirt"),
                  CategoryChip("Pants"),
                  CategoryChip("Hoodie"),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // 🛍️ PRODUCTS
            Expanded(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 16,
                ),

                child:

                    // ❌ NO PRODUCTS FOUND
                    filteredProducts.isEmpty

                        ? const Center(
                            child: Text(
                              "No products found 😢",

                              style: TextStyle(
                                fontSize: 18,
                                fontWeight:
                                    FontWeight.w500,
                              ),
                            ),
                          )

                        // ✅ PRODUCTS GRID
                        : GridView.builder(
                            itemCount:
                                filteredProducts.length,

                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              mainAxisSpacing: 16,
                              crossAxisSpacing: 16,
                              childAspectRatio: 0.68,
                            ),

                            itemBuilder:
                                (context, index) {

                              return ProductCard(
                                product:
                                    filteredProducts[
                                        index],
                              );
                            },
                          ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// 🔘 FILTER BUTTON
Widget circleButton(IconData icon) {
  return Container(
    padding: const EdgeInsets.all(10),

    decoration: const BoxDecoration(
      color: Colors.white,
      shape: BoxShape.circle,
    ),

    child: Icon(icon),
  );
}

// 🏷️ CATEGORY CHIP
class CategoryChip extends StatelessWidget {
  final String text;
  final bool isActive;

  const CategoryChip(
    this.text, {
    this.isActive = false,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 10),

      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 10,
      ),

      decoration: BoxDecoration(
        color:
            isActive ? Colors.orange : Colors.white,

        borderRadius:
            BorderRadius.circular(20),
      ),

      child: Text(
        text,

        style: TextStyle(
          color:
              isActive ? Colors.white : Colors.black,
        ),
      ),
    );
  }
}

// 🛍️ PRODUCT CARD
class ProductCard extends StatefulWidget {
  final Product product;

  const ProductCard({
    required this.product,
    super.key,
  });

  @override
  State<ProductCard> createState() =>
      _ProductCardState();
}

class _ProductCardState
    extends State<ProductCard> {

  bool isFavorite = false;

  @override
  Widget build(BuildContext context) {

    return GestureDetector(
      onTap: () {

        Navigator.push(
          context,

          MaterialPageRoute(
            builder: (context) => DetailScreen(
              product: widget.product,
            ),
          ),
        );
      },

      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,

          borderRadius:
              BorderRadius.circular(20),
        ),

        child: Column(
          children: [

            // 🖼️ IMAGE
            Expanded(
              child: Stack(
                children: [

                  Container(
                    margin: const EdgeInsets.all(8),

                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(16),

                      image: DecorationImage(
                        image: AssetImage(
                          widget.product.image,
                        ),

                        fit: BoxFit.cover,
                      ),
                    ),
                  ),

                  // ❤️ FAVORITE BUTTON
                  Positioned(
                    top: 10,
                    right: 10,

                    child: GestureDetector(
                      onTap: () {

                        setState(() {
                          isFavorite =
                              !isFavorite;
                        });

                        // ❤️ ADD / REMOVE
                        if (isFavorite) {

                          favoriteProducts.add(
                            widget.product,
                          );

                        } else {

                          favoriteProducts.remove(
                            widget.product,
                          );
                        }
                      },

                      child: Icon(
                        isFavorite
                            ? Icons.favorite
                            : Icons.favorite_border,

                        color: isFavorite
                            ? Colors.red
                            : Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // 📦 DETAILS
            Padding(
              padding: const EdgeInsets.all(8),

              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [

                  Text(
                    widget.product.name,

                    style: const TextStyle(
                      fontSize: 13,
                    ),
                  ),

                  const SizedBox(height: 4),

                  // ⭐ RATING
                  Row(
                    children: [

                      const Icon(
                        Icons.star,
                        size: 14,
                        color: Colors.orange,
                      ),

                      const SizedBox(width: 4),

                      Text(
                        widget.product.rating
                            .toString(),
                      ),
                    ],
                  ),

                  const SizedBox(height: 4),

                  // 💰 PRICE
                  Text(
                    "\$${widget.product.price}",

                    style: const TextStyle(
                      color: Colors.orange,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}