import 'package:flutter/material.dart';
import '../data/favorite_data.dart';
import 'detail_screen.dart';

class WishlistScreen extends StatelessWidget {
  const WishlistScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: const Color(0xFFEFEFEF),

      body: SafeArea(
        child: Column(
          children: [

            const SizedBox(height: 10),

            // 🔝 HEADER
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16),

              child: Row(
                children: [

                  IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },

                    icon: const Icon(
                      Icons.arrow_back,
                    ),
                  ),

                  const Spacer(),

                  const Text(
                    "URBNDRIP",

                    style: TextStyle(
                      fontFamily: "Inter",
                      fontWeight: FontWeight.bold,
                      fontStyle: FontStyle.italic,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // ❤️ TITLE
            const Padding(
              padding:
                  EdgeInsets.symmetric(horizontal: 16),

              child: Align(
                alignment: Alignment.centerLeft,

                child: Text(
                  "My Wishlist",

                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // ❤️ EMPTY STATE
            if (favoriteProducts.isEmpty)
              const Expanded(
                child: Center(
                  child: Text(
                    "No favorite products yet ❤️",

                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              )

            // 🛍️ FAVORITE PRODUCTS
            else
              Expanded(
                child: GridView.builder(
                  padding:
                      const EdgeInsets.symmetric(
                    horizontal: 16,
                  ),

                  itemCount:
                      favoriteProducts.length,

                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    childAspectRatio: 0.68,
                  ),

                  itemBuilder:
                      (context, index) {

                    final product =
                        favoriteProducts[index];

                    return GestureDetector(
                      onTap: () {

                        Navigator.push(
                          context,

                          MaterialPageRoute(
                            builder: (context) =>
                                DetailScreen(
                              product: product,
                            ),
                          ),
                        );
                      },

                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,

                          borderRadius:
                              BorderRadius.circular(
                                  20),
                        ),

                        child: Column(
                          children: [

                            // 🖼️ IMAGE
                            Expanded(
                              child: Stack(
                                children: [

                                  Container(
                                    margin:
                                        const EdgeInsets
                                            .all(8),

                                    decoration:
                                        BoxDecoration(
                                      borderRadius:
                                          BorderRadius
                                              .circular(
                                                  16),

                                      image:
                                          DecorationImage(
                                        image: AssetImage(
                                          product.image,
                                        ),

                                        fit:
                                            BoxFit.cover,
                                      ),
                                    ),
                                  ),

                                  const Positioned(
                                    top: 10,
                                    right: 10,

                                    child: Icon(
                                      Icons.favorite,
                                      color: Colors.red,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // 📦 DETAILS
                            Padding(
                              padding:
                                  const EdgeInsets.all(
                                      8),

                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment
                                        .start,

                                children: [

                                  Text(
                                    product.name,
                                  ),

                                  const SizedBox(
                                      height: 4),

                                  Row(
                                    children: [

                                      const Icon(
                                        Icons.star,
                                        size: 14,
                                        color: Colors
                                            .orange,
                                      ),

                                      const SizedBox(
                                          width: 4),

                                      Text(
                                        product.rating
                                            .toString(),
                                      ),
                                    ],
                                  ),

                                  const SizedBox(
                                      height: 4),

                                  Text(
                                    "\$${product.price}",

                                    style:
                                        const TextStyle(
                                      color: Colors
                                          .orange,

                                      fontWeight:
                                          FontWeight
                                              .bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}